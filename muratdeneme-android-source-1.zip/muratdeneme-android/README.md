# muratdeneme Android başlangıç projesi

## İçerik
- Bağımsız Android uygulama kimliği: `com.muratdeneme.app`
- Ülke kodu seçimi: Almanya (+49), Türkiye (+90)
- Telefon numarası giriş ekranı
- Basit giriş/kupon ana ekranı taslağı

## Android Studio'da açma
1. Android Studio'yu açın.
2. `muratdeneme-android` klasörünü Open ile seçin.
3. Gradle senkronizasyonunun tamamlanmasını bekleyin.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) seçin.

## Önemli
Bu ilk sürüm bir arayüz/prototiptir. SMS göndermez, hesap oluşturmaz ve Trendyol sunucularına bağlanmaz.
Gerçek SMS doğrulaması için güvenli bir backend, SMS sağlayıcısı (ör. Firebase Phone Auth veya uyumlu bir servis),
gerekli ülke izinleri ve uygulamaya ait yapılandırma gerekir. Sağlayıcı gizli anahtarları APK içine koymayın.
Trendyol'un marka, kod, sunucu veya hesap sistemlerini taklit etmez.
