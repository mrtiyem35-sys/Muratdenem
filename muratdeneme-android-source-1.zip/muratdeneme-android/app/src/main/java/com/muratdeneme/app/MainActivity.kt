package com.muratdeneme.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

private data class Country(val label: String, val dial: String, val maxDigits: Int)
private val countries = listOf(
    Country("Almanya", "+49", 15),
    Country("Türkiye", "+90", 10)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MuratDenemeApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MuratDenemeApp() {
    var selected by remember { mutableStateOf(countries[0]) }
    var number by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf("Telefon numaranı seçerek devam et.") }

    MaterialTheme {
        Scaffold { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("muratdeneme", style = MaterialTheme.typography.headlineLarge)
                Text("Telefon ile giriş", style = MaterialTheme.typography.titleLarge)
                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded }
                ) {
                    OutlinedTextField(
                        value = "${selected.label} (${selected.dial})",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Ülke kodu") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        countries.forEach { country ->
                            DropdownMenuItem(
                                text = { Text("${country.label} (${country.dial})") },
                                onClick = {
                                    selected = country
                                    number = ""
                                    expanded = false
                                    notice = "Seçilen ülke: ${country.label}"
                                }
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = number,
                    onValueChange = { input ->
                        number = input.filter { it.isDigit() }.take(selected.maxDigits)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Telefon numarası") },
                    prefix = { Text(selected.dial) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true
                )
                Button(
                    onClick = {
                        notice = if (number.length >= 7) {
                            "Numara biçimi alındı. SMS gönderimi için sunucu ve SMS sağlayıcısı yapılandırılmalı."
                        } else {
                            "Lütfen geçerli bir telefon numarası gir."
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Devam et") }
                Text(notice, style = MaterialTheme.typography.bodyMedium)
                HorizontalDivider()
                Text("Kuponlar ve kampanyalar", style = MaterialTheme.typography.titleMedium)
                Text("Kupon alanı sonraki geliştirme aşamasında eklenecek.")
            }
        }
    }
}
